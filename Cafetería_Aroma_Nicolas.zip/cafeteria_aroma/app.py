from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def inicio():
    return render_template('index.html')

@app.route('/servicios')
def servicios():
    return render_template('servicios.html')

@app.route('/contacto', methods=['GET', 'POST'])
def contacto():
    mensaje = None
    if request.method == 'POST':
        mensaje = request.form.get('recomendacion')
    return render_template('contacto.html', mensaje=mensaje)

if __name__ == '__main__':
    app.run(debug=True)
