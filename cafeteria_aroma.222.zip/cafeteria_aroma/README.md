# Cafetería Aroma

## Descripción
Aplicación web creada con Flask y Jinja2 hecha para mostrar una cafeteria y algunos de sus servios, es básica, pero busca ser amigable y agradable para la persona que la vea.

## Ejecución
Al correr el programa se le mostrará un enlace al usuario, que es el siguiente:
   http://127.0.0.1:5000
   desde ahí se podrá ver el trabajo con los requesitos pedidos por el profesor. 
   

## Autor
Trabajo hecho por Nicolas Roncancio, ID: 957212
